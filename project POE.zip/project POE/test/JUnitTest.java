/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class JUnitTest {
    
    
    public JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
         System.out.println("Before all tests");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("After all tests");
    }
    
    @Before
    public void setUp() {
        System.out.println("Before a test");
    }
    
    @After
    public void tearDown() {
        System.out.println("After a test");
    }
    
     @Test
    public void testSendMessage_IncreasesCount() {
        MessageManager manager = new MessageManager();
        manager.sendMessage("+27718693002", "Hi Mike, can you join us for dinner tonight");

        assertEquals(1, manager.getMessageCount());

        Message sentMsg = manager.getMessages().get(0);
        assertEquals("+27718693002", sentMsg.getRecipientNumber());
        assertEquals("Hi Mike, can you join us for dinner tonight", sentMsg.getMessageContent());
        assertNotNull(sentMsg.getMessageId());
        assertNotEquals(0, sentMsg.getMessageHash());
    }

    @Test
    public void testDiscardMessage_DoesNotIncreaseCount() {
        MessageManager manager = new MessageManager();
        // discard = do nothing
        assertEquals(0, manager.getMessageCount());
    }
}
    
    



    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}

