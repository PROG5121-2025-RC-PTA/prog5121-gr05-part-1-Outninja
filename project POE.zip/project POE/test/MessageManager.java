
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
public class MessageManager {
    private List<Message> messages = new ArrayList<>();

    public void sendMessage(String recipient, String content) {
        Message message = new Message(recipient, content);
        messages.add(message);
    }

    public int getMessageCount() {
        return messages.size();
    }

    public List<Message> getMessages() {
        return messages;
    }
}
    

