/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package project.poe;

import java.awt.event.ActionEvent;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class ProjectPOETest {
    
    public ProjectPOETest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class ProjectPOE.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        ProjectPOE.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of actionPerformed method, of class ProjectPOE.
     */
    @Test
    public void testActionPerformed() {
        System.out.println("actionPerformed");
        ActionEvent e = null;
        ProjectPOE instance = new ProjectPOE();
        instance.actionPerformed(e);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of <error> method, of class ProjectPOE.
     */
    @Test
    public void test<error>_1args_1() {
        System.out.println("<error>");
        Object = null;
        ProjectPOE instance = new ProjectPOE();
        Object expResult = null;
        Object result = instance.<error>(<error>);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of <error> method, of class ProjectPOE.
     */
    @Test
    public void test<error>_1args_2() {
        System.out.println("<error>");
        Object = null;
        ProjectPOE instance = new ProjectPOE();
        Object expResult = null;
        Object result = instance.<error>(<error>);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of <error> method, of class ProjectPOE.
     */
    @Test
    public void test<error>1() {
        System.out.println("<error>");
        ProjectPOE instance = new ProjectPOE();
        Object expResult = null;
        Object result = instance.<error>();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of <error> method, of class ProjectPOE.
     */
    @Test
    public void test<error>2() {
        System.out.println("<error>");
        ProjectPOE instance = new ProjectPOE();
        Object expResult = null;
        Object result = instance.<error>();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of $$anonymousClasses method, of class ProjectPOE.
     */
    @Test
    public void test$$anonymousClasses() {
        System.out.println("$$anonymousClasses");
        ProjectPOE instance = new ProjectPOE();
        instance.$$anonymousClasses();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
