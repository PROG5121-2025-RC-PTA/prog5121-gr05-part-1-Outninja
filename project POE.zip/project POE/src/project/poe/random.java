/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.poe;
import java.util.Random;
/**
 *
 * @author RC_Student_lab
 */
class random {
    private static final Random rand = new Random();

    public static int nextInt(int bound) {
        return rand.nextInt(bound);
    }
}

    

