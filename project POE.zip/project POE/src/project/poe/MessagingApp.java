/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.poe;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class MessagingApp {
    
     private Scanner scanner;

    public MessagingApp() {
        scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println("Welcome to the Messaging App!");

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Compose New Message");
            System.out.println("2. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    composeMessage();
                    break;
                case 2:
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void composeMessage() {
        System.out.print("Enter your phone number: ");
        String sender = scanner.nextLine();

        System.out.print("Enter receiver's phone number: ");
        String receiver = scanner.nextLine();

        System.out.print("Enter your message: ");
        String message = scanner.nextLine();

        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to Send Later");
        System.out.print("Choose option (1-3): ");

        int option = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (option) {
            case 1:
                SendMessage send = new SendMessage(sender, receiver, message);
                send.send();
                break;
            case 2:
                System.out.println("Message discarded.");
                break;
            case 3:
                storeMessage(sender, receiver, message);
                break;
            default:
                System.out.println("Invalid option.");
        }
    }

    private void storeMessage(String sender, String receiver, String message) {
        try (FileWriter fw = new FileWriter("pending_messages.txt", true)) {
            fw.write(sender + "|" + receiver + "|" + message + "\n");
            System.out.println("Message saved for later.");
        } catch (IOException e) {
            System.out.println("Error saving message: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        MessagingApp app = new MessagingApp();
        app.start();
    }
}
