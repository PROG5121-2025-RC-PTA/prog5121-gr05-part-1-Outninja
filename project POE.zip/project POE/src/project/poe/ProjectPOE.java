/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project.poe;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.text.NumberFormatter;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;






/**
 *
 * @author RC_Student_lab
 */
public class ProjectPOE implements ActionListener{

    
    private static JLabel userlabel;
    private static JTextField userText;
    private static JLabel passwordLabel;
    private static JPasswordField passwordText;
    private static JLabel NumberLabel;
    private static JFormattedTextField numField;
    private static JButton button;
    private static JLabel success;
    private static JButton anotherButton;
    //private static String registeredUsername ="";
    //private static String registeredPassword ="";
   // private static String registeredPhone ="";
    private static JPanel panel;
    private static List<users> registeredUsers = new ArrayList<>();
    private static JTextField messageField;
    private static Object hexString;

    

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
       

       //thsi the panelwindow that holds the labels and fields 
       panel = new JPanel();
       loadUserFromFile();
       JFrame frame = new JFrame();
       frame.setSize(350, 200);
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
      
       
       frame.add(panel);
       panel.setLayout(null);
    
       //username label
       panel.setLayout(null);
       userlabel =new JLabel("Username");
       userlabel.setBounds(10, 20, 80, 25);
       panel.add(userlabel);
       
       //user text field the user will type in here
       userText =new JTextField(20);
       userText.setBounds(100, 20 ,165, 25);
       panel.add(userText);
       
       //password label
       passwordLabel = new JLabel("Password");
       passwordLabel.setBounds(10,50,80,25);
       panel.add(passwordLabel);
       
       //user text field the password will not be visible
       passwordText = new JPasswordField();
       passwordText.setBounds(100,50,165,25);
       panel.add(passwordText);
       JLabel transcript = new JLabel();
       transcript.setBounds(10,140,300,25);
       panel.add(transcript);
       
       //phone number label
       NumberLabel = new JLabel("SANumber +27");
       NumberLabel.setBounds(10,75,100,25);
       panel.add(NumberLabel);
       
       //phonenumber format this field only allows numbers in it but not start with 0
       //reference openAI(2025)chatgpt(https://chat.openai.com/chat)
       NumberFormat format =NumberFormat.getIntegerInstance();
       format.setGroupingUsed(false);
       NumberFormatter formatter = new NumberFormatter(format);
       formatter.setValueClass(Integer.class);
       formatter.setAllowsInvalid(false);
       
       numField =new JFormattedTextField(formatter);
       numField.setBounds(100,80,165,25);
       panel.add(numField);
       
       //this is the button for sign up
       button = new JButton("Register");
       button.setBounds(10,130,85,25);
       button.addActionListener(new ProjectPOE());
       panel.add(button);
       
       //succes is the button working when pressed
       success = new JLabel("");
       success.setBounds(10,110,300,25);
       panel.add(success);
       
       //this the another button for login
       anotherButton = new JButton("Login");
       anotherButton.setBounds(150,130,80,25);
       anotherButton.addActionListener(new ProjectPOE());
       panel.add(anotherButton);
       //sets the visibility for the labels, field and buttons
       frame.setVisible(true); 
    }
    private void handleRegistration(){
        
    }
    // Display home screen with list of online users after login
    private void showLoginPanel(){
        panel.removeAll();
        panel.repaint();
        panel.revalidate();
        panel.setLayout(null);
       
        JLabel loginUserLabel = new JLabel("Username");
        loginUserLabel.setBounds(50,30,80,25);
        panel.add(loginUserLabel);
        
        JTextField loginUserField = new JTextField(20);
        loginUserField.setBounds(140,30,160,25);
        panel.add(loginUserField);
        
        JLabel loginPasswordLabel = new JLabel("Password");
        loginPasswordLabel.setBounds(50,70,80,25);
        panel.add(loginPasswordLabel);
        
        JPasswordField loginPasswordField = new JPasswordField();
        loginPasswordField.setBounds(140,70,160,25);
        panel.add(loginPasswordField);
        
        JLabel loginMessage= new JLabel("");
        loginMessage.setBounds(10,110,300,25);
        panel.add(loginMessage);
        
        JButton submitLoginButton = new JButton("Login");
        submitLoginButton.setBounds(120,130,100,25);
        panel.add(submitLoginButton);
        
        // Handle login logic when user clicks "Login" button.
        submitLoginButton.addActionListener((ActionEvent evt) -> {
            String enteredUser = loginUserField.getText();
            String enteredPass = new String(loginPasswordField.getPassword());
            
            boolean found = false;
            // Loop through registered users and display them as chat options excluding self
            for(users user : registeredUsers){
                if(user.getusername().equals(enteredUser) && user.getpassword().equals(enteredPass)){
                    found = true;
                    break;
                }
                if(found){
                    showhomepanel(enteredUser);
                }
                else{
                    
                    loginMessage.setText("incorrect Username or password");
                }
                
            }
        });
        panel.repaint();
        panel.revalidate();
    }

    @Override
    // Determines which button was clicked: Register or Login, and processes accordingly
    public void actionPerformed(ActionEvent e) {
         if (e.getSource() ==button){
             handleRegistration();
            }
         else if(e.getSource()== anotherButton){
             showLoginPanel();
         }
       String Username =userText.getText();
       String password = new String(passwordText.getPassword());
       String number = numField.getText();
       
       // Validate username and password inputs for format and length requirements.
       boolean hasUnderscore =Username.contains("_");
       boolean usernamelongEnough = Username.length()>=5;
       boolean validUsername =hasUnderscore &&usernamelongEnough;
       
       boolean hasUpper =password.matches(".*[A-Z].*");
       boolean hasNumber =password.matches(".*[0-9].*");
       boolean hasSpecial =password.matches(".*[!@#$%^&*()].*");
       boolean passwordlongEnough =password.length()>=8;
       boolean validpassword = hasUpper && hasNumber && hasSpecial && passwordlongEnough;
       boolean isNineDigits = number.matches("0\\d{8}");
  
       //if the user name is not valid the they will be a red message that will show up 
       if(!validUsername){
           success.setForeground(Color.red);
           if(!hasUnderscore && !passwordlongEnough){
            success.setText("Username should have 5 characters and have a underscore.");
           }
           //else if the username those not have underscore show error message
           else if(!hasUnderscore){
           success.setText("username should have an underscore.");
           }
           //else the username does not have 5 characters show message
       else{
           success.setText("Username must have 5 characters");
           }
           return;
           //if the password is not valid it will show a red error message
       }
       if (!validpassword){
           success.setForeground(Color.red);
           success.setText("password must at least be 8 characters long");
          return;
       }
       //when the didits in the field is not 8digits show red error message
         if(isNineDigits){
           success.setForeground(Color.red);
           success.setText("phone number must start with 0 and be 9 digits.");
          return;
         }
         //this will register the users input data  
           //registeredUsername = Username;
           //registeredPassword =password;
           //registeredPhone =number;
           
           // If input is valid, create a new user and save to file.
           users newusers = new users(Username, password, number);
           registeredUsers.add(newusers);
           
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
               writer.write(Username + "," + password + "," + number);
               writer.newLine();
               } catch (IOException ex) {
               ex.printStackTrace();
               }

           
           
           //after everything has been entred correctly it will display a green message that show the user that the sign up is successfull 
           success.setForeground(Color.green);
           success.setText("signup successful\nPhone+27" +number);
           
          
       
           //this when the login button is been pressed with the the signup is done it willl remove all from the panel
           //reference openAI(2025)chatgpt(https://chat.openai.com/chat)
           if(e.getSource()==anotherButton){
               panel.removeAll();
               panel.repaint();
               panel.revalidate();
           
               //A new panel will be shown with new labels and fields
            //loginuser label
           JLabel LoginUserlabel = new JLabel("Username");
           LoginUserlabel.setBounds(50,30,80,25);
           panel.add(LoginUserlabel);
           
           //loginuser text field 
           JTextField LoginUserField = new JTextField(20);
           LoginUserField.setBounds(140,30,160,25);
           panel.add(LoginUserField);
           
           //login password label
           JLabel LoginpasswordLabel = new JLabel("Password");
           LoginpasswordLabel.setBounds(50,70,80,25);
           panel.add(LoginpasswordLabel);
           
           //login password field
           JPasswordField LoginpasswordField =new JPasswordField();
           LoginpasswordField.setBounds(140,70,160,25);
           panel.add(LoginpasswordField);
           
           //login message label 
           JLabel LoginMessage = new JLabel("");
           LoginMessage.setBounds(10,110,300,25);
           panel.add(LoginMessage);
           
           //this is the login button
           JButton SubmitLoginButton =new JButton("Login");
           SubmitLoginButton.setBounds(120,130,100,25);
           panel.add(SubmitLoginButton);
           
           
           SubmitLoginButton.addActionListener(new ActionListener(){
            @Override
            // //reference openAI(2025)chatgpt(https://chat.openai.com/chat)
            public void actionPerformed(ActionEvent evt){
                //declare the entered strings
                String enteredUser =LoginUserField.getText();
                String enteredPass = new String(LoginpasswordField.getPassword());
                
                //this when the users detail are equal to the registered saved data
                boolean found = false;
                for (users user : registeredUsers){
                    if (user.getusername().equals(enteredUser) && user.getpassword().equals(enteredPass)){
                     found = true;
                     break;
                    }
                }
                    if(found){
                    showhomepanel(enteredUser);
                    }
                //if the detail is not correct it should show an error message
                else{
                    LoginMessage.setForeground(Color.red);
                    LoginMessage.setText("Incorrect Username or Password");
                }
            }
               
           });
           panel.repaint();
           panel.revalidate();
           
                   }
    }
    // Sets up the login screen with username and password fields.
    private static void showhomepanel(String currentusername){
        panel.removeAll();
        panel.repaint();
        panel.revalidate();
        panel.setLayout(null);
        
        JLabel welcomeLabel =new JLabel("welcome to Quickchat," + currentusername);
        welcomeLabel.setBounds(10,10,200,25);
        panel.add(welcomeLabel);
        
        JLabel userListLabel = new JLabel("Online Users;");
        userListLabel.setBounds(10,40,100,25);
        panel.add(userListLabel);
        
        int yOffset = 70;
        for(users u : registeredUsers){
         if(!u.getusername().equals(currentusername)){
        JButton userButton = new JButton(u.getusername());
        userButton.setBounds(10, yOffset, 200, 25);
        panel.add(userButton);
        
        String receiver = u.getusername();
        userButton.addActionListener(new ActionListener(){
            
            public void actionPrformed(ActionEvent e){
                openChatWindow(currentusername, receiver);
            }

            @Override
            public void actionPerformed(ActionEvent e) {
               openChatWindow(currentusername, receiver);
            }
        });
        }
        }
        
         }
        // Read users from "users.txt" file and populate the registeredUsers list
       private static void loadUserFromFile(){
           try(BufferedReader reader = new BufferedReader(new FileReader("users.txt"))){
             String line;
             while ((line = reader.readLine()) !=null){
                 String[] parts = line.split(",");
                 if(parts.length ==3){
                     String username = parts[0];
                     String password = parts[1];
                     String phone = parts[2];
                     registeredUsers.add(new users(username,password,phone));
                 }
             }
           }
           catch(IOException e){
               System.out.println("no previou user file found.Strating fresh.");
           }
        }
       // Creates a chat window between the sender and receiver with a chat log area and input field
       private static void openChatWindow(String sender,String receiver){
           JFrame chatFrame = new JFrame("Chat with" +receiver);
           chatFrame.setSize(500,500);
           chatFrame.setLayout(null);
           
       JTextArea chatArea = new JTextArea();
       chatArea.setBounds(10,10,460,350);
       chatArea.setEditable(false);
       chatFrame.add(chatArea);
       
       messageField = new JTextField();
       messageField.setBounds(10,370,360,30);
       chatFrame.add(messageField);
       
       JButton sendButton = new JButton("send");
       sendButton.setBounds(380,370,90,30);
       chatFrame.add(sendButton);
       
    // Send the message and generate a unique message ID when "Send" is clicked
    sendButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String message = messageField.getText().trim();
        if (message.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Message cannot be empty.");
            return;
        }

        // Generate unique message ID using hash
        String messageHash = generateMessageHash(message + System.currentTimeMillis());
        String messageId = "MSG-" + messageHash.substring(0, 8);

        // Format message line to save
        String formattedMessage = "ID: " + messageId + 
                                  " | To: " + receiver + 
                                  " | Hash: " + messageHash.substring(0, 16) +  // Optional truncation
                                  " | Message: " + message;

        // Append to chat area
        chatArea.append(formattedMessage + "\n");

        // Save to chat file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(sender + "_to_" + receiver + ".chat", true))) {
            writer.write(formattedMessage);
            writer.newLine();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Failed to send message.");
            return;
        }

        // Clear input
        messageField.setText("");
    }
});

      chatFrame.setVisible(true);
           
       }
       // Creates a SHA-256 hash from the message used to generate unique message IDs
      public static String generateMessageHash(String message) {
    try {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedHash = digest.digest(message.getBytes());

        StringBuilder hexString = new StringBuilder();
        for (byte b : encodedHash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    } catch (NoSuchAlgorithmException ex) {
        Logger.getLogger(ProjectPOE.class.getName()).log(Level.SEVERE, null, ex);
        throw new RuntimeException("SHA-256 not supported", ex);
    }
}
      
     public class MessageApp {
    public static void main(String[] args) {
        System.out.println("Launching GUI...");
        SwingUtilities.invokeLater(() -> new ProjectPOE());
    }
}
 
    

}
           

    

