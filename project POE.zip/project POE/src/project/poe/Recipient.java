/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.poe;

/**
 *
 * @author RC_Student_lab
 */
public class Recipient {
    private String username;
    
    public Recipient(String username){
        this.username = username.trim();
    }
    public String getUsername(){
        return username;
    }
    public boolean isValid(){
        return !username.isEmpty();
    }
    
    @Override
    public String toString(){
        return username;
    }
    
}
