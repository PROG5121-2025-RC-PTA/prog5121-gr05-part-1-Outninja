/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.poe;

import java.util.concurrent.atomic.AtomicInteger;
/**
 *
 * @author RC_Student_lab
 */
public class messageid {
    private static final AtomicInteger idcounter = new AtomicInteger(1);
    
    private final int id;
    private final String sender;
    private final String receiver;
    private final String content;
    private boolean seen;
    
    public messageid(String sender, String receiver, String content){
        this.id = generateRandomId();
        this.sender = sender;
        this.receiver = receiver;
        this.content = content;
        this.seen = false;
    }
    
    private int generateRandomId(){
        return 100000 + random.nextInt(900000);
    }
    public int getId(){
        return id;
    }
    public String getSender(){
        return sender;
    }
    public String getReceiver(){
        return receiver;
        
    }
    public String getContent(){
        return content;
    }
    public boolean isSeen(){
        return seen;
    }
    public void markSeen(){
        this.seen = true;
    }
    @Override
    public String toString(){
        return "Message #" + id + "from" + sender + "to" + receiver + ":" + content;
    }
    
}
