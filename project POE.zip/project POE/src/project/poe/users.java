/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.poe;

/**
 *
 * @author RC_Student_lab
 */
public class users {
    private String username;
    private String password;
    private String phone;
    
    public users(String username, String password, String phone){
        this.username =username;
        this.password = password;
        this.phone = phone;
    }
    public String getusername(){
        return username;
    }
    public String getpassword(){
        return password;
    }
    public String getphone(){
        return this.phone;
    }
}
