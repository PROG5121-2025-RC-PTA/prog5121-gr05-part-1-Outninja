/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.poe;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Base64;

/**
 *
 * @author RC_Student_lab
 */
public class Message {
    private final String messageId;
    private final String sender;
    private final String recipient;
    private final String content;
    private final LocalDateTime timestamp;
    private final String messageHash;
    private boolean isDeleted;
    
    public Message(String sender, String recipient, String content) {
        this.sender = sender;
        this.recipient = recipient;
        this.content = content;
        this.timestamp = LocalDateTime.now();
        this.messageId = generateMessageId();
        this.messageHash = generateMessageHash();
        this.isDeleted = false;
        
    }
    
    private String generateMessageId() {
        return "MSG-" + System.currentTimeMillis();
        
    }
    private String generateMessageHash() {
        try {
            String data = sender + recipient + content + timestamp.toString();
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(data.getBytes());
            return Base64.getEncoder().encodeToString(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error generating message hash", e);
        }
    }
    
    public String getMessageId() { return messageId; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getContent() { return content; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public String getMessageHash() { return messageHash; }
    public boolean isDeleted() { return isDeleted; }

    public void markAsDeleted() {
        this.isDeleted = true;
    }
    
    @Override
    public String toString() {
        return String.format(
            "ID: %s | From: %s | To: %s | Content: %s | Sent: %s | Hash: %s",
            messageId, sender, recipient, content, 
            timestamp.toString(), messageHash
        );
    }
}

