/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.poe;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

/**
 *
 * @author RC_Student_lab
 */
public class showReportWindow {
    
    
    
 private static void showReportWindow(String currentUsername) {
    JFrame reportFrame = new JFrame("Reports");
    reportFrame.setSize(500, 400);
    reportFrame.setLayout(null);

    JButton viewAllBtn = new JButton("1. View All Messages");
    JButton longestBtn = new JButton("2. Longest Message");
    JButton searchByIdBtn = new JButton("3. Search by Message ID");
    JButton searchByRecipientBtn = new JButton("4. Search by Recipient");
    JButton deleteByHashBtn = new JButton("5. Delete by Message Hash");
    JButton fullReportBtn = new JButton("6. Full Message Report");

    viewAllBtn.setBounds(20, 20, 220, 30);
    longestBtn.setBounds(20, 60, 220, 30);
    searchByIdBtn.setBounds(20, 100, 220, 30);
    searchByRecipientBtn.setBounds(20, 140, 220, 30);
    deleteByHashBtn.setBounds(20, 180, 220, 30);
    fullReportBtn.setBounds(20, 220, 220, 30);

    JTextArea output = new JTextArea();
    output.setEditable(false);
    output.setBounds(250, 20, 220, 300);
    reportFrame.add(output);

    reportFrame.add(viewAllBtn);
    reportFrame.add(longestBtn);
    reportFrame.add(searchByIdBtn);
    reportFrame.add(searchByRecipientBtn);
    reportFrame.add(deleteByHashBtn);
    reportFrame.add(fullReportBtn);

    // Add listeners here later...

    reportFrame.setVisible(true);
}

    
}
