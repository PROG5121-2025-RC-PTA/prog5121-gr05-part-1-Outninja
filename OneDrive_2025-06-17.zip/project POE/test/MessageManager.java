
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
//import java.util.Collections;
//import java.util.Comparator;
//import java.util.stream.Collectors;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */

public class MessageManager {
    private final List<String> messages = new ArrayList<>();

    public void sendMessage(String to, String content) throws IOException {
        String messageId = "MSG-" + generateHash(content + System.currentTimeMillis()).substring(0, 8);
        String hash = generateHash(content).substring(0, 16);
        String formatted = "ID: " + messageId + " | To: " + to + " | Hash: " + hash + " | Message: " + content;
        messages.add(formatted);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("test_" + to + ".chat", true))) {
            writer.write(formatted);
            writer.newLine();
        }
    }

    public List<String> getSentMessages() {
        return messages;
    }

    public String generateHash(String message) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(message.getBytes());
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) {
                String h = Integer.toHexString(0xff & b);
                if (h.length() == 1) hex.append("0");
                hex.append(h);
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}
