/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;
import java.util.*;
import project.poe.MessageManager;

/**
 *
 * @author RC_Student_lab
 */
public class JUnitTestpart3 {
    
  private MessageManager manager;

    @Before
    public void setUp() {
        manager = new MessageManager();
    }

    @After
    public void tearDown() {
        // Optional cleanup
    }
    
    class FakeMessageManager {
        private List<String> messages = new ArrayList<>();

        void sendMessage(String to, String message) {
            String id = "MSG-" + Integer.toHexString(message.hashCode()).toUpperCase();
            String hash = Integer.toHexString(message.hashCode()).toUpperCase();
            messages.add("ID: " + id + " | To: " + to + " | Hash: " + hash + " | Message: " + message);
        }

        String getLongestMessage() {
            String longest = "";
            for (String msg : messages) {
                if (msg.length() > longest.length()) {
                    longest = msg;
                }
            }
            return longest;
        }

        String searchById(String id) {
            for (String msg : messages) {
                if (msg.contains(id)) return msg;
            }
            return null;
        }

        String getReport() {
            return String.join("\n", messages);
        }

        List<String> getAll() { return messages; }
    }

    @Test
    public void testLongestMessage() {
        FakeMessageManager m = new FakeMessageManager();
        m.sendMessage("john", "hi");
        m.sendMessage("john", "this is a long message that should be longest");
        String result = m.getLongestMessage();
        assertTrue(result.contains("long message"));
    }

    @Test
    public void testSearchByMessageId() {
        FakeMessageManager m = new FakeMessageManager();
        m.sendMessage("john", "check this ID");
        String msg = m.getAll().get(0);
        String id = msg.split(" ")[1];
        String found = m.searchById(id);
        assertNotNull(found);
        assertTrue(found.contains("check this ID"));
    }

    @Test
    public void testFullReport() {
        FakeMessageManager m = new FakeMessageManager();
        m.sendMessage("john", "one");
        m.sendMessage("jane", "two");
        String report = m.getReport();
        assertTrue(report.contains("john"));
        assertTrue(report.contains("jane"));
    }

    @Test
    public void testSendMessageStoresCorrectly() throws IOException {
        manager.sendMessage("testUser", "Test message content");
        List<String> sent = manager.getSentMessages();
        assertEquals(1, sent.size());
        assertTrue(sent.get(0).contains("Test message content"));
    }

    @Test
    public void testMessageHashGeneration() {
        String hash1 = manager.generateHash("Hello World");
        String hash2 = manager.generateHash("Hello World");
        assertEquals(hash1, hash2); // same input = same hash
    }

    @Test
    public void testMessageHashIsNotNull() {
        String hash = manager.generateHash("Test123");
        assertNotNull(hash);
        assertEquals(64, hash.length()); // SHA-256 hash in hex is 64 chars
    }
}